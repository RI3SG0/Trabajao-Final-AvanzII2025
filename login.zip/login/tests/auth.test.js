const request = require('supertest');
const app = require('../index');

describe('Post /login', () =>{
    test('todos los campos son requeridos', async ()=>{
        const response = await request(app).post('/login').send({
            username: "usuario1",
            password: "password123"
        });

        expect(response.statusCode).toBe(200);
        expect(response.body).toHaveProperty('token');
    });

    test('registro creado correctamente', async ()=>{
        const response = await request(app).post('/login').send({
            username: "usuario1",
            password: "wrongpassword"
        });

        expect(response.statusCode).toBe(401);
        expect(response.body).toHaveProperty('error','Credenciales inválidas');
    });


});